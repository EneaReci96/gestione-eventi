// utils/categories.js

// Array di categorie predefinite per gli eventi
const eventCategories = [
    'Concerto',
    'Mostra',
    'Conferenza',
    'Sport',
    'Teatro',
    'Festival',
    'Workshop',
    'Webinar',
    'Altro',
  ];
  
  module.exports = eventCategories;
  